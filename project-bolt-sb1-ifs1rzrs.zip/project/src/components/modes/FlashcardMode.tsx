import { useState, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Shuffle, RotateCcw } from 'lucide-react';
import { kanjiData } from '../../data/kanjiData';
import { KanjiItem } from '../../types';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const BADGE_COLORS: Record<string, string> = {
  'Kata Benda': 'bg-blue-100 text-blue-500',
  'Kata Kerja': 'bg-emerald-100 text-emerald-500',
  'Kata Sifat い': 'bg-amber-100 text-amber-500',
  'Kata Sifat な': 'bg-rose-100 text-rose-500',
};

export default function FlashcardMode() {
  const [deck, setDeck] = useState<KanjiItem[]>([...kanjiData]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);

  const current = deck[index];

  const goNext = useCallback(() => {
    setFlipped(false);
    setTimeout(() => setIndex((i) => Math.min(i + 1, deck.length - 1)), 150);
  }, [deck.length]);

  const goPrev = useCallback(() => {
    setFlipped(false);
    setTimeout(() => setIndex((i) => Math.max(i - 1, 0)), 150);
  }, []);

  const handleShuffle = () => {
    setFlipped(false);
    setDeck(shuffle(kanjiData));
    setIndex(0);
  };

  const handleReset = () => {
    setFlipped(false);
    setDeck([...kanjiData]);
    setIndex(0);
  };

  const progress = ((index + 1) / deck.length) * 100;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-1">Mode Flashcard</h2>
        <p className="text-gray-400 text-sm">Klik kartu untuk membalik — lihat hiragana dan artinya</p>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2">
          <button
            onClick={handleShuffle}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-pink-50 text-pink-500 hover:bg-pink-100 text-xs font-medium transition-all"
          >
            <Shuffle className="w-3.5 h-3.5" /> Acak
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gray-50 text-gray-500 hover:bg-gray-100 text-xs font-medium transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
        </div>
        <span className="text-sm font-semibold text-pink-500">
          {index + 1} <span className="text-gray-300 font-normal">/ {deck.length}</span>
        </span>
      </div>

      <div className="w-full bg-pink-100 rounded-full h-1.5 mb-8 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-pink-400 to-rose-400 rounded-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div
        className="flashcard-scene cursor-pointer mb-8 select-none"
        onClick={() => setFlipped((f) => !f)}
      >
        <div className={`flashcard-inner ${flipped ? 'flipped' : ''}`}>
          <div className="flashcard-face flashcard-front flex flex-col items-center justify-center bg-white rounded-3xl shadow-xl border-2 border-pink-100 p-8 min-h-64">
            <p className="text-xs font-semibold text-pink-300 uppercase tracking-widest mb-6">Kanji</p>
            <p className="text-8xl sm:text-9xl font-bold text-gray-800 leading-none">{current.kanji}</p>
            <p className="text-xs text-gray-300 mt-8">tap untuk membalik ↕</p>
          </div>

          <div className="flashcard-face flashcard-back flex flex-col items-center justify-center bg-gradient-to-br from-pink-50 to-rose-50 rounded-3xl shadow-xl border-2 border-pink-200 p-8 min-h-64">
            <span className={`text-xs font-semibold px-3 py-1 rounded-full mb-4 ${BADGE_COLORS[current.kategori]}`}>
              {current.kategori}
            </span>
            <p className="text-4xl font-bold text-gray-800 mb-2">{current.kanji}</p>
            <p className="text-xl text-pink-500 font-medium mb-3">{current.hiragana}</p>
            <p className="text-lg text-gray-700 font-semibold text-center">{current.arti}</p>
            <div className="mt-5 pt-5 border-t border-pink-100 w-full text-center">
              <p className="text-sm text-gray-600 font-medium">{current.contohKalimat}</p>
              <p className="text-xs text-gray-400 mt-1 italic">{current.terjemahanKalimat}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-4">
        <button
          onClick={goPrev}
          disabled={index === 0}
          className="flex items-center gap-1.5 px-5 py-3 rounded-2xl bg-white border-2 border-pink-100 text-pink-500 font-semibold hover:border-pink-300 hover:bg-pink-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-sm"
        >
          <ChevronLeft className="w-5 h-5" /> Prev
        </button>

        <button
          onClick={() => setFlipped((f) => !f)}
          className="px-6 py-3 rounded-2xl bg-gradient-to-r from-pink-400 to-rose-400 text-white font-semibold hover:from-pink-500 hover:to-rose-500 transition-all shadow-md shadow-pink-200 active:scale-95"
        >
          Balik Kartu
        </button>

        <button
          onClick={goNext}
          disabled={index === deck.length - 1}
          className="flex items-center gap-1.5 px-5 py-3 rounded-2xl bg-white border-2 border-pink-100 text-pink-500 font-semibold hover:border-pink-300 hover:bg-pink-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-sm"
        >
          Next <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
