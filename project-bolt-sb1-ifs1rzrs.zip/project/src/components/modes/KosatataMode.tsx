import { useState } from 'react';
import { Search } from 'lucide-react';
import { kanjiData } from '../../data/kanjiData';
import { Kategori } from '../../types';

const KATEGORI_LIST: { key: Kategori | 'Semua'; label: string; color: string }[] = [
  { key: 'Semua', label: 'Semua', color: 'bg-pink-500 text-white' },
  { key: 'Kata Benda', label: 'Kata Benda', color: 'bg-blue-500 text-white' },
  { key: 'Kata Kerja', label: 'Kata Kerja', color: 'bg-emerald-500 text-white' },
  { key: 'Kata Sifat い', label: 'Sifat い', color: 'bg-amber-500 text-white' },
  { key: 'Kata Sifat な', label: 'Sifat な', color: 'bg-rose-500 text-white' },
];

const BADGE_COLORS: Record<Kategori, string> = {
  'Kata Benda': 'bg-blue-100 text-blue-600',
  'Kata Kerja': 'bg-emerald-100 text-emerald-600',
  'Kata Sifat い': 'bg-amber-100 text-amber-600',
  'Kata Sifat な': 'bg-rose-100 text-rose-600',
};

export default function KosatataMode() {
  const [activeKategori, setActiveKategori] = useState<Kategori | 'Semua'>('Semua');
  const [search, setSearch] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filtered = kanjiData.filter((item) => {
    const matchKategori = activeKategori === 'Semua' || item.kategori === activeKategori;
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      item.kanji.includes(q) ||
      item.hiragana.includes(q) ||
      item.arti.toLowerCase().includes(q);
    return matchKategori && matchSearch;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-1">Mode Kosakata</h2>
        <p className="text-gray-400 text-sm">100 Kanji N5 — klik kartu untuk melihat contoh kalimat</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-300 w-4 h-4" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari kanji, hiragana, atau arti..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border-2 border-pink-100 bg-pink-50/30 text-gray-700 placeholder-pink-200 focus:outline-none focus:border-pink-300 text-sm transition-all"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {KATEGORI_LIST.map((k) => (
            <button
              key={k.key}
              onClick={() => setActiveKategori(k.key)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeKategori === k.key
                  ? k.color + ' shadow-md scale-105'
                  : 'bg-gray-100 text-gray-500 hover:bg-pink-50 hover:text-pink-500'
              }`}
            >
              {k.label}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs text-gray-400 mb-4">
        Menampilkan <span className="font-semibold text-pink-500">{filtered.length}</span> kosakata
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
            className="bg-white rounded-2xl border border-pink-100 p-4 cursor-pointer hover:shadow-md hover:border-pink-200 transition-all duration-200 group"
          >
            <div className="flex items-start justify-between mb-2">
              <span className="text-4xl font-bold text-gray-800 group-hover:text-pink-600 transition-colors leading-none">
                {item.kanji}
              </span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${BADGE_COLORS[item.kategori]}`}>
                {item.kategori}
              </span>
            </div>
            <p className="text-sm text-pink-400 font-medium mb-1">{item.hiragana}</p>
            <p className="text-sm text-gray-600 font-medium">{item.arti}</p>

            {expandedId === item.id && (
              <div className="mt-3 pt-3 border-t border-pink-50 animate-fade-in">
                <p className="text-sm text-gray-700 font-medium">{item.contohKalimat}</p>
                <p className="text-xs text-gray-400 mt-1 italic">{item.terjemahanKalimat}</p>
              </div>
            )}

            <div className="mt-2 text-right">
              <span className="text-xs text-pink-200 group-hover:text-pink-400 transition-colors">
                {expandedId === item.id ? '▲ tutup' : '▼ contoh'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <p className="text-4xl mb-3">🔍</p>
          <p className="text-gray-400 text-sm">Tidak ada hasil untuk pencarian ini</p>
        </div>
      )}
    </div>
  );
}
