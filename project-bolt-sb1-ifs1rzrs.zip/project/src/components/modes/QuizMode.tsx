import { useState, useCallback } from 'react';
import { RotateCcw, CheckCircle, XCircle, Trophy } from 'lucide-react';
import { kanjiData } from '../../data/kanjiData';
import { KanjiItem } from '../../types';

const TOTAL_QUESTIONS = 20;

interface Question {
  kanji: KanjiItem;
  choices: string[];
  correct: string;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function generateQuiz(): Question[] {
  const shuffled = shuffle(kanjiData);
  const selected = shuffled.slice(0, TOTAL_QUESTIONS);

  return selected.map((item) => {
    const wrongPool = kanjiData.filter((k) => k.id !== item.id);
    const wrongs = shuffle(wrongPool)
      .slice(0, 3)
      .map((k) => k.arti);
    const choices = shuffle([item.arti, ...wrongs]);
    return { kanji: item, choices, correct: item.arti };
  });
}

type Phase = 'start' | 'playing' | 'result';

export default function QuizMode() {
  const [phase, setPhase] = useState<Phase>('start');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);

  const startQuiz = useCallback(() => {
    setQuestions(generateQuiz());
    setCurrentIndex(0);
    setScore(0);
    setSelected(null);
    setAnswered(false);
    setPhase('playing');
  }, []);

  const handleChoice = (choice: string) => {
    if (answered) return;
    setSelected(choice);
    setAnswered(true);
    if (choice === questions[currentIndex].correct) {
      setScore((s) => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 >= TOTAL_QUESTIONS) {
      setPhase('result');
    } else {
      setCurrentIndex((i) => i + 1);
      setSelected(null);
      setAnswered(false);
    }
  };

  const getScoreColor = (s: number) => {
    if (s >= 18) return 'text-emerald-500';
    if (s >= 14) return 'text-blue-500';
    if (s >= 10) return 'text-amber-500';
    return 'text-rose-500';
  };

  const getScoreMessage = (s: number) => {
    if (s >= 18) return 'Luar biasa! Kamu sangat pintar! 🏆';
    if (s >= 14) return 'Bagus sekali! Terus semangat! ✨';
    if (s >= 10) return 'Lumayan! Lebih banyak berlatih ya! 💪';
    return 'Jangan menyerah! Coba lagi! 🌸';
  };

  if (phase === 'start') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-1">Mode Quiz</h2>
          <p className="text-gray-400 text-sm">Uji pemahamanmu tentang 100 Kanji N5</p>
        </div>

        <div className="bg-white rounded-3xl border-2 border-pink-100 p-8 text-center shadow-sm">
          <div className="text-6xl mb-4">📝</div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Siap Belajar?</h3>
          <div className="space-y-3 text-sm text-gray-500 mb-8 max-w-xs mx-auto text-left">
            <div className="flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-pink-500 flex-shrink-0 flex items-center justify-center text-xs font-bold mt-0.5">1</span>
              <span>Kamu akan mendapatkan <strong>{TOTAL_QUESTIONS} soal</strong> pilihan ganda</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-pink-500 flex-shrink-0 flex items-center justify-center text-xs font-bold mt-0.5">2</span>
              <span>Soal diambil <strong>secara acak</strong> dari 100 kanji</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-pink-500 flex-shrink-0 flex items-center justify-center text-xs font-bold mt-0.5">3</span>
              <span>Pilih arti yang <strong>paling tepat</strong> untuk setiap kanji</span>
            </div>
          </div>
          <button
            onClick={startQuiz}
            className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-pink-400 to-rose-400 text-white font-bold text-sm hover:from-pink-500 hover:to-rose-500 transition-all shadow-md shadow-pink-200 active:scale-95"
          >
            Mulai Quiz!
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white rounded-3xl border-2 border-pink-100 p-8 text-center shadow-sm">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-pink-50 mb-4">
            <Trophy className="w-10 h-10 text-pink-400" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">Quiz Selesai!</h3>
          <p className="text-gray-400 text-sm mb-6">{getScoreMessage(score)}</p>

          <div className="inline-block mb-8">
            <p className="text-sm text-gray-400 mb-1">Nilai kamu:</p>
            <p className={`text-5xl font-bold ${getScoreColor(score)}`}>
              {score} <span className="text-2xl text-gray-300 font-normal">/ {TOTAL_QUESTIONS}</span>
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="bg-emerald-50 rounded-2xl p-4">
              <p className="text-2xl font-bold text-emerald-500">{score}</p>
              <p className="text-xs text-gray-400 mt-1">Benar</p>
            </div>
            <div className="bg-rose-50 rounded-2xl p-4">
              <p className="text-2xl font-bold text-rose-500">{TOTAL_QUESTIONS - score}</p>
              <p className="text-xs text-gray-400 mt-1">Salah</p>
            </div>
            <div className="bg-blue-50 rounded-2xl p-4">
              <p className="text-2xl font-bold text-blue-500">{Math.round((score / TOTAL_QUESTIONS) * 100)}%</p>
              <p className="text-xs text-gray-400 mt-1">Akurasi</p>
            </div>
          </div>

          <button
            onClick={startQuiz}
            className="flex items-center gap-2 mx-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-pink-400 to-rose-400 text-white font-semibold hover:from-pink-500 hover:to-rose-500 transition-all shadow-md shadow-pink-200 active:scale-95"
          >
            <RotateCcw className="w-4 h-4" /> Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  const question = questions[currentIndex];
  const progress = ((currentIndex + 1) / TOTAL_QUESTIONS) * 100;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-gray-800">Mode Quiz</h2>
        <span className="text-sm font-semibold text-pink-500">
          {currentIndex + 1} <span className="text-gray-300 font-normal">/ {TOTAL_QUESTIONS}</span>
        </span>
      </div>

      <div className="w-full bg-pink-100 rounded-full h-2 mb-6 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-pink-400 to-rose-400 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="bg-white rounded-3xl border-2 border-pink-100 p-8 text-center shadow-sm mb-4">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-widest mb-4">
          Apa arti dari kanji ini?
        </p>
        <p className="text-8xl font-bold text-gray-800 leading-none mb-2">{question.kanji.kanji}</p>
        <p className="text-sm text-gray-300">{question.kanji.hiragana}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
        {question.choices.map((choice, i) => {
          let btnClass = 'bg-white border-2 border-pink-100 text-gray-700 hover:border-pink-300 hover:bg-pink-50';

          if (answered) {
            if (choice === question.correct) {
              btnClass = 'bg-emerald-50 border-2 border-emerald-300 text-emerald-700';
            } else if (choice === selected && choice !== question.correct) {
              btnClass = 'bg-rose-50 border-2 border-rose-300 text-rose-700';
            } else {
              btnClass = 'bg-white border-2 border-gray-100 text-gray-400 opacity-60';
            }
          }

          return (
            <button
              key={i}
              onClick={() => handleChoice(choice)}
              disabled={answered}
              className={`relative flex items-center gap-3 px-5 py-4 rounded-2xl font-medium text-sm text-left transition-all duration-200 ${btnClass} ${!answered ? 'active:scale-95' : ''}`}
            >
              <span className="w-6 h-6 rounded-full bg-pink-50 text-pink-400 flex-shrink-0 flex items-center justify-center text-xs font-bold">
                {String.fromCharCode(65 + i)}
              </span>
              <span>{choice}</span>
              {answered && choice === question.correct && (
                <CheckCircle className="w-4 h-4 text-emerald-500 ml-auto flex-shrink-0" />
              )}
              {answered && choice === selected && choice !== question.correct && (
                <XCircle className="w-4 h-4 text-rose-500 ml-auto flex-shrink-0" />
              )}
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="animate-fade-in">
          <div className={`flex items-center gap-2 px-4 py-3 rounded-xl mb-4 text-sm font-medium ${selected === question.correct ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
            {selected === question.correct ? (
              <><CheckCircle className="w-4 h-4" /> Benar! Jawaban yang tepat.</>
            ) : (
              <><XCircle className="w-4 h-4" /> Jawaban benar: <strong>{question.correct}</strong></>
            )}
          </div>
          <button
            onClick={handleNext}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-400 to-rose-400 text-white font-semibold hover:from-pink-500 hover:to-rose-500 transition-all shadow-md shadow-pink-200 active:scale-95"
          >
            {currentIndex + 1 >= TOTAL_QUESTIONS ? 'Lihat Hasil' : 'Soal Berikutnya →'}
          </button>
        </div>
      )}
    </div>
  );
}
