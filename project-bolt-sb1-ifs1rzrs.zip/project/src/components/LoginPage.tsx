import { useState } from 'react';
import { Lock } from 'lucide-react';
import SakuraPetals from './SakuraPetals';

interface LoginPageProps {
  onLogin: () => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'nihongo') {
      onLogin();
    } else {
      setError('Password salah, coba lagi ya!');
      setShake(true);
      setPassword('');
      setTimeout(() => setShake(false), 600);
    }
  };

  return (
    <div className="min-h-screen login-bg flex items-center justify-center relative overflow-hidden">
      <SakuraPetals />

      <div className={`relative z-10 w-full max-w-sm mx-4 ${shake ? 'shake' : ''}`}>
        <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-10 border border-pink-100 text-center">
          <div className="mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-pink-100 mb-4">
              <span className="text-3xl">🌸</span>
            </div>
            <h1 className="text-3xl font-bold text-pink-700 mb-1 tracking-wide">
              Selamat Belajar
            </h1>
            <p className="text-pink-400 text-sm font-medium tracking-widest uppercase">
              Kanji N5 · JLPT
            </p>
          </div>

          <div className="mb-8">
            <p className="text-4xl font-bold text-gray-800 tracking-widest">日本語</p>
            <p className="text-xs text-gray-400 mt-1">Nihongo — Belajar Kanji N5</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-pink-300 w-4 h-4" />
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="Masukkan password..."
                className="w-full pl-11 pr-4 py-3 rounded-xl border-2 border-pink-100 bg-pink-50/50 text-gray-700 placeholder-pink-200 focus:outline-none focus:border-pink-300 focus:bg-white transition-all text-sm"
                autoFocus
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-100 rounded-xl px-4 py-2.5 text-sm text-red-500 font-medium animate-fade-in">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-400 to-rose-400 text-white font-semibold text-sm tracking-wide hover:from-pink-500 hover:to-rose-500 active:scale-95 transition-all duration-200 shadow-md shadow-pink-200"
            >
              Masuk
            </button>
          </form>

          <p className="mt-6 text-xs text-gray-300">
            Hint: bahasa yang kita pelajari ✨
          </p>
        </div>
      </div>
    </div>
  );
}
