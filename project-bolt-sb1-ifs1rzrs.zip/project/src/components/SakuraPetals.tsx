import { useMemo } from 'react';

interface Petal {
  id: number;
  left: number;
  delay: number;
  duration: number;
  size: number;
}

export default function SakuraPetals() {
  const petals = useMemo<Petal[]>(() => {
    return Array.from({ length: 20 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 10,
      duration: 7 + Math.random() * 6,
      size: 10 + Math.random() * 12,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {petals.map((petal) => (
        <div
          key={petal.id}
          className="sakura-petal absolute"
          style={{
            left: `${petal.left}%`,
            width: `${petal.size}px`,
            height: `${petal.size}px`,
            animationDelay: `${petal.delay}s`,
            animationDuration: `${petal.duration}s, ${petal.duration * 0.7}s`,
          }}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="text-pink-300 opacity-60 w-full h-full">
            <path d="M12 2C9.5 2 7.5 4 7.5 6.5C5 6.5 3 8.5 3 11C3 13.5 5 15.5 7.5 15.5C7.5 18 9.5 20 12 20C14.5 20 16.5 18 16.5 15.5C19 15.5 21 13.5 21 11C21 8.5 19 6.5 16.5 6.5C16.5 4 14.5 2 12 2Z" />
          </svg>
        </div>
      ))}
    </div>
  );
}
