import { BookOpen, CreditCard, Trophy, LogOut } from 'lucide-react';
import { AppMode } from '../types';

interface NavigationProps {
  activeMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  onLogout: () => void;
}

const navItems: { mode: AppMode; label: string; icon: React.ReactNode; jp: string }[] = [
  { mode: 'kosakata', label: 'Kosakata', jp: '語彙', icon: <BookOpen className="w-5 h-5" /> },
  { mode: 'flashcard', label: 'Flashcard', jp: '暗記', icon: <CreditCard className="w-5 h-5" /> },
  { mode: 'quiz', label: 'Quiz', jp: 'クイズ', icon: <Trophy className="w-5 h-5" /> },
];

export default function Navigation({ activeMode, onModeChange, onLogout }: NavigationProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-pink-100 shadow-sm">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🌸</span>
            <div>
              <p className="text-sm font-bold text-pink-600 leading-none">漢字 N5</p>
              <p className="text-xs text-gray-400 leading-none">100 Kanji</p>
            </div>
          </div>

          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.mode}
                onClick={() => onModeChange(item.mode)}
                className={`relative flex flex-col items-center gap-0.5 px-4 py-2 rounded-xl transition-all duration-200 text-xs font-medium ${
                  activeMode === item.mode
                    ? 'bg-pink-50 text-pink-600'
                    : 'text-gray-400 hover:text-pink-400 hover:bg-pink-50/50'
                }`}
              >
                {item.icon}
                <span className="hidden sm:block">{item.label}</span>
                {activeMode === item.mode && (
                  <span className="absolute -bottom-px left-4 right-4 h-0.5 bg-pink-400 rounded-full" />
                )}
              </button>
            ))}
          </nav>

          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-rose-400 hover:bg-rose-50 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:block">Keluar</span>
          </button>
        </div>
      </div>
    </header>
  );
}
