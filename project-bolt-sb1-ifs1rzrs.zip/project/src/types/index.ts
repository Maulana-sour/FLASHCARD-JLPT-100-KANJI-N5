export type Kategori = 'Kata Kerja' | 'Kata Sifat い' | 'Kata Sifat な' | 'Kata Benda';

export interface KanjiItem {
  id: number;
  kanji: string;
  hiragana: string;
  arti: string;
  kategori: Kategori;
  contohKalimat: string;
  terjemahanKalimat: string;
}

export type AppMode = 'kosakata' | 'flashcard' | 'quiz';
