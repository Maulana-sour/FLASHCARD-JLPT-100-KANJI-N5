import { useState, useEffect } from 'react';
import { AppMode } from './types';
import LoginPage from './components/LoginPage';
import Navigation from './components/Navigation';
import KosatataMode from './components/modes/KosatataMode';
import FlashcardMode from './components/modes/FlashcardMode';
import QuizMode from './components/modes/QuizMode';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('kanji_auth') === 'true';
  });
  const [activeMode, setActiveMode] = useState<AppMode>('kosakata');

  useEffect(() => {
    localStorage.setItem('kanji_auth', isLoggedIn ? 'true' : 'false');
  }, [isLoggedIn]);

  const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => {
    localStorage.removeItem('kanji_auth');
    setIsLoggedIn(false);
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="app-bg">
      <Navigation
        activeMode={activeMode}
        onModeChange={setActiveMode}
        onLogout={handleLogout}
      />
      <main>
        {activeMode === 'kosakata' && <KosatataMode />}
        {activeMode === 'flashcard' && <FlashcardMode />}
        {activeMode === 'quiz' && <QuizMode />}
      </main>
    </div>
  );
}
